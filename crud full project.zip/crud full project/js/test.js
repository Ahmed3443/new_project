

var regex = / ./